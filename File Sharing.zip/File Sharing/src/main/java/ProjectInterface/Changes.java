/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectInterface;

import javafx.scene.control.ListView;

/**
 *
 * @author Sean O Connor
 */
public interface Changes {
     public void updates(ListView lv, String Path);
    
}
